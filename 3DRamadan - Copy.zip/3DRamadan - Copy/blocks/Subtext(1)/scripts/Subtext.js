const Patches = require('Patches');
Promise.all([
  Patches.outputs.getString('text'),
  Patches.outputs.getScalar('from'),
  Patches.outputs.getScalar('to'),
]).then(([text,from,to])=>{
  let _text = text.pinLastValue();
  let _from = from.pinLastValue();
  let _to = to.pinLastValue();
  
  const update = () =>{
    let _subtext = _text.substring(_from,_to);
    Patches.inputs.setString('subtext',_subtext);
    Patches.inputs.setScalar('len',_text.length);
    Patches.inputs.setScalar('sublen',_subtext.length);
  }
  
  text.monitor().subscribe(({newValue})=>{
    _text = newValue;
    update();
  });

  from.monitor().subscribe(({newValue})=>{
    _from = newValue;
    update();
  });

  to.monitor().subscribe(({newValue})=>{
    _to = newValue;
    update();
  });

  update();
});